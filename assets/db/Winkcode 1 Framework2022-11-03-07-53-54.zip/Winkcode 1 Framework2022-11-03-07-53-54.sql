#
# TABLE STRUCTURE FOR: coba
#

DROP TABLE IF EXISTS `coba`;

CREATE TABLE `coba` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `coba` (`id`, `nama`) VALUES (1, 'aaaa');
INSERT INTO `coba` (`id`, `nama`) VALUES (2, 'dasdsadsadsa');


#
# TABLE STRUCTURE FOR: kategori
#

DROP TABLE IF EXISTS `kategori`;

CREATE TABLE `kategori` (
  `id_kat` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `for_modul` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_kat`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (2, 'Kategori b', '-', '-');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (4, 'Desa', '-', 'jenis_lokasi');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (5, 'Radio', '-', 'jenis_perangkat');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (6, 'Kecamatan', '', 'jenis_lokasi');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (7, 'OPD', '', 'jenis_lokasi');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (8, 'PDE', '', 'jenis_perangkat');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (9, 'Access Point', '', 'jenis_perangkat');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (10, 'Router', '', 'jenis_perangkat');
INSERT INTO `kategori` (`id_kat`, `cat_name`, `note`, `for_modul`) VALUES (11, 'Repeater Bojong', '', 'jenis_perangkat');


#
# TABLE STRUCTURE FOR: master_access
#

DROP TABLE IF EXISTS `master_access`;

CREATE TABLE `master_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nm_access` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `id_menu` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (7, 'Dashboard', 'Akses Ke dashboard', '2022-11-01 12:39:28', 1, 6);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (8, 'Pengaturan Aplikasi', 'Akses Ke parameter System', '2022-11-01 12:42:42', 1, 13);
INSERT INTO `master_access` (`id`, `nm_access`, `note`, `created_at`, `created_by`, `id_menu`) VALUES (9, 'Kategori', 'Akses Ke menu Kategori', '2022-11-01 12:43:51', 1, 10);


#
# TABLE STRUCTURE FOR: sy_config
#

DROP TABLE IF EXISTS `sy_config`;

CREATE TABLE `sy_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conf_name` varchar(50) NOT NULL,
  `conf_val` text NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (3, 'APP_NAME', 'Winkcode 1 Framework', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (8, 'OPD_NAME', 'Peternak Kode', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (9, 'LEFT_FOOTER', '<strong>Copyright</strong> <a href=\"http://www.youtube.com/peternakkode\" target=\"_blank\">Peternak Kode</a> © 2019', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (10, 'RIGHT_FOOTER', 'Codeigniter 3 + Harviacode + SfHelper + SfJs', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (11, 'VISI_MISI', 'Dilengkapi dengan tambahan helper PHP dan JS', '');
INSERT INTO `sy_config` (`id`, `conf_name`, `conf_val`, `note`) VALUES (12, 'OPD_ADDR', '<a href=\"http://www.youtube.com/peternakkode\" target=\"_blank\">Peternak Kode</a>', '');


#
# TABLE STRUCTURE FOR: sy_menu
#

DROP TABLE IF EXISTS `sy_menu`;

CREATE TABLE `sy_menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(30) DEFAULT '',
  `redirect` int(1) DEFAULT NULL,
  `url` varchar(100) DEFAULT '',
  `parent` int(11) DEFAULT 0,
  `icon` varchar(30) DEFAULT NULL,
  `note` varchar(100) DEFAULT NULL,
  `order_no` int(5) DEFAULT NULL,
  `created_by` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` varchar(20) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_menu`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (5, 'Menu Config', 0, 'sy_menu', 0, 'fa-wrench', '', 10, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (6, 'Dashboard', 0, 'backend', 0, 'fa-tachometer-alt', '', 0, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (10, 'Category', 0, 'kategori', 0, 'fa-th-list', '', 4, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (13, 'Parameter System', 0, 'sy_config', 0, 'fa-list', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (14, 'Users', 0, 'users', 18, 'fa-users', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (15, 'Group Users', 0, 'user_group', 18, 'fa-users', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (16, 'User Access', 0, 'user_access', 18, 'fa fa-user', '', 8, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (17, 'Master Access', 0, 'master_access', 18, 'fa fa-key', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');
INSERT INTO `sy_menu` (`id_menu`, `label`, `redirect`, `url`, `parent`, `icon`, `note`, `order_no`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (18, 'Management Users', 0, 'users', 0, 'fa fa-users', '', 9, '', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: user_access
#

DROP TABLE IF EXISTS `user_access`;

CREATE TABLE `user_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_group` int(11) DEFAULT NULL,
  `kd_access` varchar(12) DEFAULT NULL,
  `nm_access` varbinary(100) DEFAULT NULL,
  `is_allow` int(1) DEFAULT NULL COMMENT '0=false,1=true',
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`) VALUES (5, 2, '1', NULL, 0, NULL);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`) VALUES (8, 1, '1', NULL, 1, NULL);
INSERT INTO `user_access` (`id`, `id_group`, `kd_access`, `nm_access`, `is_allow`, `note`) VALUES (9, 1, '4', NULL, 1, NULL);


#
# TABLE STRUCTURE FOR: user_group
#

DROP TABLE IF EXISTS `user_group`;

CREATE TABLE `user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `user_group` (`id`, `group_name`, `note`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (1, 'Developer', 'full akses', NULL, NULL, NULL, NULL);
INSERT INTO `user_group` (`id`, `group_name`, `note`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES (2, 'Administrator', 'Admin Aplikasi', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(250) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `id_group` int(11) DEFAULT NULL COMMENT 'fk dari tabel user_group',
  `foto` varchar(250) DEFAULT NULL,
  `telp` varchar(250) DEFAULT NULL,
  `note` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `note_1` text DEFAULT NULL,
  PRIMARY KEY (`id_user`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `users` (`id_user`, `fullname`, `username`, `password`, `email`, `id_group`, `foto`, `telp`, `note`, `created_by`, `updated_by`, `created_at`, `updated_at`, `note_1`) VALUES (1, 'Admin Jaringan', 'dev', '227edf7c86c02a44d17eec9aa5b30cd1', 'dev@email.com', 1, 'a4.jpg', '085643242654', '-', 1, 1, '2018-03-13 03:06:55', '2019-01-31 11:09:12', '');
INSERT INTO `users` (`id_user`, `fullname`, `username`, `password`, `email`, `id_group`, `foto`, `telp`, `note`, `created_by`, `updated_by`, `created_at`, `updated_at`, `note_1`) VALUES (2, 'Kepala', 'kepala', '836b1f7f9b7f9bf98f1f645302defc59', 'kepalasimpjari@gmail.com', 0, '', '', '', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL);


